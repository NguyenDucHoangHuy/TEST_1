package NguyenDucHoangHuy;

public interface Interface2_HoangHuy_Sapxep {
	public void  sapxepTang(int a[]);
	 public void sapxepGiam(int a[]);
}
