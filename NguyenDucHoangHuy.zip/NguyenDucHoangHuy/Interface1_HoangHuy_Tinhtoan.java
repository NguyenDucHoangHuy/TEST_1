package NguyenDucHoangHuy;

public interface Interface1_HoangHuy_Tinhtoan {
	  public  double cong (double a,double b) ;  
	  public double tru (double a,double b) ;    
	  public double nhan (double a,double b) ;  
	  public double chia  (double a,double b) ;  	
}
