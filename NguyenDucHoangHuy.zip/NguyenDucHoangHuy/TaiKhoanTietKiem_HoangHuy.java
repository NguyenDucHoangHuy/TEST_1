package NguyenDucHoangHuy;

public class TaiKhoanTietKiem_HoangHuy extends TaiKhoanNganHang_HoàngHuy{
	 private double laisuat;
	 public TaiKhoanTietKiem_HoangHuy(String soTaikhoan, double soDu, double laisuat) {
	super(soTaikhoan, soDu);
		this.laisuat=laisuat;
}
@Override
	public void napTien(double tiennap) {
if(tiennap>0) {
	soDu+=tiennap;
	System.out.println("Nap "+tiennap+"VND vao tai khoan "+soTaikhoan);
}
}	
@Override
	public void rutTien(double tienrut) {
		if((tienrut>0)&&(soDu-tienrut>0)) {
			soDu-=tienrut;
			System.out.println("Rut "+tienrut+ "VND tu tai khoan "+soTaikhoan);
		}
		else System.out.println("Tien rut khong hop le");
	}

	@Override
	public void inSodu() {
    System.out.println("So du tai khoan "+soTaikhoan+": "+soDu+ " VND");
		
	}
}



