package Demo_Exception;
import java.util.Scanner;
import java.util.Random;
 public class Gamechiendau_exeption {
public static void main(String[] args) {
	  Scanner scanner = new Scanner(System.in);

      System.out.println("Chao mung den voi game nhap vai !");
      System.out.print("Nhap ten nhan vat cua ban: ");
      String playerName = scanner.nextLine();
       Character player=new Character(playerName,120,25);
       Character monster = null;
       System.out.println(playerName + " vs. Quai vat");
      System.out.println("Hay bat dau cuoc chien!");

      while (player.isAlive() && (monster == null || monster.isAlive())) {
    	    try {
    	        if (monster == null || !monster.isAlive()) {
    	            monster = spawnMonster();
    	        }
    	        player.attack(monster);
                 if (monster != null && monster.isAlive()) {
    	            monster.attack(player);
    	        } else {
    	            monster = null;
    	        }
                 if (monster == null || !monster.isAlive()) {
    	            System.out.println(playerName + " chien thang!");
    	            break;
    	        }
    	    } catch (KhongTimThayQuaiVat e) {
    	        System.out.println(e.getMessage());
    	    } catch (QuaiVatQuaManh e) {
    	        System.out.println(e.getMessage());
    	        break;
    	    }
    	}
     scanner.close();
}

private static Character spawnMonster() throws  KhongTimThayQuaiVat,QuaiVatQuaManh {
    int monsterStrength = new Random().nextInt(25) + 5;
    int monsterHealth=80;
    Character quaivat=new Character("Quai vat",monsterHealth,monsterStrength);
    if (monsterStrength < 20) {
        throw new KhongTimThayQuaiVat("Khong tim thay quai vat!");
    }
    if (  monsterStrength>2*15) {
    throw new  QuaiVatQuaManh("Quai vat qua manh. Ban khong the danh bai no!");
    }
   return quaivat;
	 
}
}