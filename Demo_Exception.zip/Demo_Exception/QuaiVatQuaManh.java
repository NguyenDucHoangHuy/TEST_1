package Demo_Exception;

public class  QuaiVatQuaManh extends Exception{
	public QuaiVatQuaManh(String message) {
		super(message);
	}
}