package Demo_Exception;
import java.util.Random;
public class Character {
	protected  String name;
	protected int health;
	protected int attack;

	    public Character(String name, int health, int attack) {
	        this.name = name;
	        this.health = health;
	        this.attack = attack;
	    }

	    public void attack(Character enemy) {
	        int damage = new Random().nextInt(attack) + 1;
	        enemy.takeDamage(damage);
	        System.out.println(name + " tan cong " + enemy.name + " gay " + damage + " sat thuong.");
	    }

	    public void takeDamage(int damage) {
	        health -= damage;
	        if (health < 0) {
	            health = 0;
	        }
	        System.out.println(name + " con " + health + " diem mau.");
	    }

	    public boolean isAlive() {
	        return health > 0;
	    }
	}

