package Demo_Exception;

	public class KhongTimThayQuaiVat extends Exception{
		 public KhongTimThayQuaiVat(String message) {
			 super (message);
		 }
	}

